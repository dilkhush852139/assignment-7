import psycopg2
def table():

    conn = psycopg2.connect(dbname="postgres",user="postgres", password="9525", host="localhost",port="5432")
    cursor = conn.cursor()
    cursor.execute('''create table employees(Name Text, ID int, Age int); ''')

    print(" Table create successfully")
    conn.commit()
    conn.close()
def data():
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="9525", host="localhost", port="5432")
    cursor = conn.cursor()
    cursor.execute('''insert into employees(Name, ID , Age )values('sam',01,30 ); ''')
    print("data added successfully")

    print(" Table create successfully")
    conn.commit()
    conn.close()

def extract():
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="9525", host="localhost", port="5432")
    cursor = conn.cursor()
    cursor.execute('''select * from employees; ''')
    show=cursor.fetchone()

    print(show[0])

    #print(" Table create successfully")
    conn.commit()
    conn.close()
extract()